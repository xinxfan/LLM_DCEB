#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import time
import logging
import threading
from typing import List, Optional
from pathlib import Path

import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.generation.stopping_criteria import StoppingCriteria, StoppingCriteriaList
from peft import PeftModel


MAX_CONCURRENT = int(os.getenv("MAX_CONCURRENT", "4"))
_sem = threading.Semaphore(MAX_CONCURRENT)

DEFAULT_SYSTEM_PROMPT_STRICT = (
    "You are a safe, reliable and professional assistant. Strictly follow safety and compliance principles:\n"
    "- For illegal, dangerous, harmful, explicit sexual, hateful, etc. requests, clearly refuse and give safe alternatives.\n"
    "- Provide general, educational and risk-reduction guidance, not executable harmful steps.\n"
    "- Be clear and structured; suggest professional help when needed.\n"
    "- If a user request could be misused, state the risks.\n"
    "- When the user input contains multiple requests, analyze each for compliance. Refuse unreasonable ones and answer only the normal parts that comply with safety and content policies."
)


# Base and LoRA (generation)
BASE_MODEL_DIR = "/path/to/project/Meta-Llama-3-8B-Instruct"

# Llama-3 LoRA 配置
ADAPTER_PATH = "/path/to/project/llama_sft/lora_32"


# PDD prefix (optional)
PDD_PATH = "/path/to/models/pdd.txt"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
try:
    from logging.handlers import RotatingFileHandler
    LOG_PATH = Path(__file__).with_name("api_server.log")
    file_handler = RotatingFileHandler(str(LOG_PATH), maxBytes=10*1024*1024, backupCount=3, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    if not any(isinstance(h, RotatingFileHandler) for h in logger.handlers):
        logger.addHandler(file_handler)
    logger.info("Logs will be written to: %s", LOG_PATH)
except Exception as _e:
    logger.warning("File log init failed: %s", _e)

model = None
tokenizer = None
_pdd_map = {}


class ChatMessage(BaseModel):
    role: str
    content: str


class GenerateRequest(BaseModel):
    text: str
    max_new_tokens: Optional[int] = 4096

# Audit log (JSONL append)
AUDIT_JSONL_PATH = Path(__file__).with_name("api_requests.jsonl")
_audit_lock = threading.Lock()

def _append_audit_record(record: dict) -> None:
    try:
                if "request" in record and isinstance(record["request"], dict):
            req = record["request"]
            req.pop("cls_label", None)
            req.pop("augmented", None)
        
        line = (record or {})
        with _audit_lock:
            with AUDIT_JSONL_PATH.open("a", encoding="utf-8") as fh:
                import json as _json
                fh.write(_json.dumps(line, ensure_ascii=False) + "\n")
    except Exception as _audit_err:
        logger.warning("Failed to write audit log: %s", _audit_err)


def _load_pdd_map(path: str) -> dict:
    out = {}
    try:
        if not os.path.exists(path):
            return out
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                s = (line or "").strip()
                if not s:
                    continue
                if s[0:1].isdigit() and s[1:2] == ".":
                    label = s[0]
                    text = s[2:].strip()
                    out[label] = text
    except Exception as e:
        logger.warning("Failed to read pdd file: %s", e)
    return out


class StopOnSuffixes(StoppingCriteria):
    def __init__(self, stop_sequences):
        super().__init__()
        self.stop_sequences = stop_sequences

    def _endswith(self, seq, suffix):
        L = len(suffix)
        if len(seq) < L:
            return False
        return seq[-L:] == suffix

    def __call__(self, input_ids, scores=None, **kwargs):
        for row in input_ids:
            seq = row.tolist()
            for stop in self.stop_sequences:
                if self._endswith(seq, stop):
                    return True
        return False


def _tokens_for_stop_words(tok, stop_words):
    stop_ids_list = []
    for w in stop_words:
        try:
            ids = tok.convert_tokens_to_ids(w)
            if isinstance(ids, int):
                if ids >= 0:
                    stop_ids_list.append([int(ids)])
            elif isinstance(ids, list) and ids:
                clean = [int(i) for i in ids if int(i) >= 0]
                if clean:
                    stop_ids_list.append(clean)
        except Exception:
            enc = tok(w, add_special_tokens=False).get("input_ids", [])
            if enc:
                stop_ids_list.append([int(i) for i in enc if int(i) >= 0])
    uniq, seen = [], set()
    for s in stop_ids_list:
        t = tuple(s)
        if t not in seen:
            seen.add(t)
            uniq.append(s)
    return uniq


def clean_response(text: str) -> str:
    lines = text.split("\n")
    cleaned_lines = []
    for line in lines:
        if line.strip().lower().startswith("user"):
            break
        if line.strip():
            cleaned_lines.append(line)
    return "\n".join(cleaned_lines).strip()

def _preview_text(s: str, limit: int = 200) -> str:
    s = s or ""
    return s[:limit] + ("..." if len(s) > limit else "")

def _preview_messages(msgs: List[ChatMessage]) -> List[dict]:
    out = []
    for m in msgs:
        try:
            out.append({"role": m.role, "content": _preview_text(m.content)})
        except Exception:
            out.append({"role": getattr(m, "role", "?"), "content": "<unprintable>"})
    return out


def generate_response(
    messages: List[ChatMessage],
    *,
    max_new_tokens: int = 4096,
    time_budget: Optional[float] = None,
) -> str:
    "Generate: deterministic greedy with optional timeout."
    # 
    try:
        max_new_tokens = min(int(max_new_tokens), 4096)
    except Exception:
        max_new_tokens = 4096
    messages_dict = [{"role": m.role, "content": m.content} for m in messages]
    text = tokenizer.apply_chat_template(messages_dict, tokenize=False, add_generation_prompt=True)
    
    # 动态获取模型所在的 device
    if model and hasattr(model, "device"):
        device = model.device
    else:
        device = torch.device("cuda:0")
    
    model_inputs = tokenizer([text], return_tensors="pt", padding=True, add_special_tokens=False).to(device)

    try:
        im_end_id = tokenizer.convert_tokens_to_ids("<|eot_id|>")
        if isinstance(im_end_id, int) and im_end_id < 0:
            im_end_id = None
    except Exception:
        im_end_id = None

    stop_words = ["<|eot_id|>", "</s>", "\nUser:", "User:"]
    if tokenizer.eos_token is not None:
        stop_words.append(tokenizer.eos_token)
    stop_ids_list = _tokens_for_stop_words(tokenizer, stop_words)
    # stopping = StoppingCriteriaList([StopOnSuffixes(stop_ids_list)]) if stop_ids_list else None
    stopping = None #

        torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    generation_kwargs = {
        "attention_mask": model_inputs.attention_mask,
        "eos_token_id": (im_end_id if im_end_id is not None else tokenizer.eos_token_id),
        "pad_token_id": tokenizer.pad_token_id,
        "max_new_tokens": max_new_tokens,
        "do_sample": False,
        "temperature": 0.0,
        "top_k": 1,
        "top_p": 1.0,
        "repetition_penalty": 1.0,
        "no_repeat_ngram_size": 0,
        "stopping_criteria": stopping,
        "use_cache": True,
    }

        if time_budget is not None:
        try:
            # 保证为正数，避免异常
            generation_kwargs["max_time"] = max(1.0, float(time_budget))
        except Exception:
            pass

    with torch.no_grad():
        generated_ids = model.generate(model_inputs.input_ids, **generation_kwargs)


    generated_ids = [
        output_ids[len(input_ids):]
        for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
    ]
    response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    return clean_response(response)


def load_model() -> None:
    global model, tokenizer, _pdd_map
    logger.info("开始加载模型（确定性设置）...")

    # 确定性设置
    try:
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":16:8")
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.manual_seed(42)
        torch.cuda.manual_seed_all(42)
    except Exception as e:
        logger.warning(f"无法完全启用确定性算法: {e}")

    torch.set_float32_matmul_precision("high")


        target_gpus = [2]
    try:

        pid = os.getpid()

        gpu_idx = pid % len(target_gpus)
        target_device_id = target_gpus[gpu_idx]
    except Exception:
        target_device_id = 0

    logger.info(f"基座路径: {BASE_MODEL_DIR}")
    logger.info(f"LoRA路径: {ADAPTER_PATH}")
    logger.info(f"🔄 当前进程 PID={os.getpid()}，自动分配到 GPU: {target_device_id}")
    
    base = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_DIR,
        dtype=torch.bfloat16,
        device_map={"": target_device_id},
        attn_implementation="sdpa",
    )
    # 加载 LoRA adapter
    gen_model = PeftModel.from_pretrained(base, ADAPTER_PATH)

    tok = AutoTokenizer.from_pretrained(BASE_MODEL_DIR)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    if getattr(gen_model.config, "pad_token_id", None) is None:
        gen_model.config.pad_token_id = tok.pad_token_id

    globals()["model"] = gen_model.eval()
    globals()["tokenizer"] = tok
    logger.info("生成模型加载完成（基座 + LoRA Rank 32）")

        globals()["_pdd_map"] = _load_pdd_map(PDD_PATH)
    logger.info("PDD keys: %s", sorted(list(_pdd_map.keys())))


app = FastAPI(
    title="Meta-Llama-3-8B API (LoRA Rank 32)",
    description="Only /model endpoint, deterministic greedy",
    version="1.0.0",
)


@app.on_event("startup")
async def startup_event():
    # 仅加载模型，不再启动内网穿透
    load_model()
    logger.info("模型服务已就绪，本地监听端口: 8002")


@app.post("/model")
async def provide_model(req: GenerateRequest):
    if model is None or tokenizer is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    # 使用信号量限制并发进入推理阶段的请求数
    if not _sem.acquire(blocking=False):
        raise HTTPException(status_code=503, detail="服务器繁忙，请稍后重试")
    
    try:
                req_start_ts = time.time()

        user_content = req.text or ""
        if not user_content:
            raise HTTPException(status_code=422, detail="Missing text field")

                # wrapped = "{" + user_content + "}"

        # 移除分类逻辑，默认 label="1" 或直接不使用
        # cls_label = "1"
        
        # augmented = wrapped
        # try:
        #     tip = _pdd_map.get(cls_label, "").strip()
        #     if tip:
        #         augmented = f"{tip}\n{augmented}"
        # except Exception:
        #     pass

        messages = [
            ChatMessage(role="system", content=DEFAULT_SYSTEM_PROMPT_STRICT),
            ChatMessage(role="user", content=user_content),
        ]

        # 整体从接收请求到返回响应不超过 300 秒
        total_budget = 300.0
        elapsed = time.time() - req_start_ts
        remaining = total_budget - elapsed
        if remaining <= 1.0:
                        out = "当前请求处理超时（超过 300 秒），已中止生成。"
            latency_ms = int((time.time() - req_start_ts) * 1000)
        else:
                        gen_budget = remaining - 1.0
            t0 = time.time()
            out = generate_response(
                messages,
                max_new_tokens=(min(req.max_new_tokens or 4096, 4096)),
                time_budget=gen_budget,
            )
            latency_ms = int((time.time() - t0) * 1000)
        full_msgs = [{"role": m.role, "content": m.content} for m in messages]
        logger.info("[/model] request=%s", full_msgs)
        logger.info("[/model] response(%d ms)=%s", latency_ms, out)
        _append_audit_record({
            "ts": int(time.time()*1000),
            "endpoint": "/model",
            "latency_ms": latency_ms,
            "request": {"text": user_content}, # 仅保留 text
            "response": out,
        })
        return {"code": 200, "data": out}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("/model generation failed: %s", e)
        raise HTTPException(status_code=500, detail="Generation failed: " + str(e))
    finally:
        _sem.release()


if __name__ == "__main__":
    import uvicorn
    # 获取环境变量中的 workers 配置，默认为 1
        workers = int(os.getenv("WORKERS", "1"))
    
    # 启动本地服务
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8002,
        reload=False,
        workers=workers,
    )
