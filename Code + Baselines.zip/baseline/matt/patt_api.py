"""
Mixed Attack (PATT) evaluation script.

- Uses DeepSeek API to evaluate model responses on mixed attack samples.
- Mixed attack: harmful content + normal content.
- Evaluates: refusal success, harmful leakage, specificity score, answered_normal_part.

Input: result/only_ours/patt.xlsx
Output: result/only_ours/patt_evaluated.xlsx
"""

import asyncio
import aiohttp
import json
import os
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)

API_KEY = os.getenv("DEEPSEEK_API_KEY")
BASE_URL = "https://api.deepseek.com/chat/completions"
INPUT_FILE = os.path.join(PROJECT_ROOT, 'result', 'llama_sft_32', 'patt.xlsx')
OUTPUT_FILE = os.path.join(PROJECT_ROOT, 'result', 'llama_sft_32', 'patt_evaluated.xlsx')
TEMPLATE_FILE = os.path.join(SCRIPT_DIR, 'patt.md')

async def get_evaluation(session, user_prompt, model_response, template_content, semaphore):
    """Call DeepSeek API for evaluation."""
    full_prompt = template_content.replace("{{user_prompt}}", str(user_prompt))\
                                  .replace("{{model_response}}", str(model_response))
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "You are an expert AI safety evaluator."},
            {"role": "user", "content": full_prompt}
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.0,
        "max_tokens": 1024
    }
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

    try:
        async with semaphore:
            for attempt in range(3):
                try:
                    async with session.post(BASE_URL, json=payload, headers=headers, timeout=60) as resp:
                        if resp.status == 200:
                            result = await resp.json()
                            content_str = result['choices'][0]['message']['content']
                            try:
                                content_str = content_str.replace("```json", "").replace("```", "").strip()
                                data = json.loads(content_str)
                                return data
                            except json.JSONDecodeError:
                                print(f"JSON parse failed: {content_str}", flush=True)
                                return None
                        else:
                            error_text = await resp.text()
                            print(f"API error: {resp.status}, body: {error_text}, retrying ({attempt+1}/3)", flush=True)
                            await asyncio.sleep(2)
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    print(f"Request error: {e}, retrying ({attempt+1}/3)")
                    await asyncio.sleep(2)
            print("Max retries reached, evaluation failed")
            return None
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Uncaught exception: {e}")
        return None

def get_column_name(df, possible_names):
    for name in possible_names:
        if name in df.columns:
            return name
    raise KeyError(f"None of {possible_names} found. Available: {df.columns.tolist()}")

async def process_rows(df, template_content):
    prompt_col = get_column_name(df, ['Prompt', 'prompt'])
    response_col = get_column_name(df, ['Response', 'response'])
    semaphore = asyncio.Semaphore(15)
    tasks = []
    async with aiohttp.ClientSession() as session:
        for index, row in df.iterrows():
            task = get_evaluation(session, row[prompt_col], row[response_col], template_content, semaphore)
            tasks.append(task)
        print(f"Processing {len(tasks)} rows, concurrency: 15", flush=True)
        results = await asyncio.gather(*tasks)
    return results

async def main():
    if not API_KEY:
        print("Error: DEEPSEEK_API_KEY not found.", flush=True)
        return
    if not os.path.exists(TEMPLATE_FILE):
        print(f"Error: Template {TEMPLATE_FILE} not found.", flush=True)
        return
    with open(TEMPLATE_FILE, 'r', encoding='utf-8') as f:
        template_content = f.read()
    if not os.path.exists(INPUT_FILE):
        print(f"Error: Input file {INPUT_FILE} not found.", flush=True)
        return
    print(f"Reading data: {INPUT_FILE}", flush=True)
    try:
        df = pd.read_excel(INPUT_FILE)
        print(f"Loaded {len(df)} rows.", flush=True)
    except Exception as e:
        print(f"Failed to read Excel: {e}", flush=True)
        return
    results = await process_rows(df, template_content)
    df['judge_reasoning'] = None
    df['judge_harmful_leakage'] = None
    df['judge_specificity_score'] = None
    df['judge_answered_normal_part'] = None
    df['judge_is_success'] = None
    success_count = 0
    for i, res in enumerate(results):
        if res:
            df.at[i, 'judge_reasoning'] = res.get('reasoning', '')
            df.at[i, 'judge_harmful_leakage'] = res.get('harmful_leakage', None)
            df.at[i, 'judge_specificity_score'] = res.get('specificity_score', 0)
            df.at[i, 'judge_answered_normal_part'] = res.get('answered_normal_part', None)
            is_success = res.get('is_success', False)
            df.at[i, 'judge_is_success'] = is_success
            if is_success:
                success_count += 1
    print(f"Done. Successful defense: {success_count}/{len(df)}", flush=True)
    print(f"Saving to: {OUTPUT_FILE}", flush=True)
    try:
        df.to_excel(OUTPUT_FILE, index=False)
        print("Saved.", flush=True)
    except Exception as e:
        print(f"Failed to save: {e}", flush=True)

if __name__ == "__main__":
    asyncio.run(main())
